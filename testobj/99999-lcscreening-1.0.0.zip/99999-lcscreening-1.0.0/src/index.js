const qalyears = require('@kgrid/qalyutil/qalylookup')
const ptlevels = require('@kgrid/qalyutil/ptlvlConverter')
const lookupindexer = require('@kgrid/qalyutil/lookupIndexer')
const config = require('./config.json')

function qalygain(inputs){
  var features = inputFeatures(inputs)
  var ptlvl = ptlevels(config,features)
  var luindex = lookupindexer(__dirname, config, inputs.features.age, ptlvl)
  var outputObj = {}
  outputObj.id=config.id
  outputObj.service = config.service
  if(Object.keys(luindex).length!=0){
    outputObj.data_source = {}
    outputObj.data_source.updateDate = config.updatedOn
    outputObj.data_source.type = config.datatype
    outputObj.qaly = qalyears(config, luindex)
  } else {
    outputObj.error = "No data available."
  }
  return outputObj
}

function inputFeatures(pt){
  /* ----- Derived Features ----- */
  //  Lung Cancer Screening  //

  var features = JSON.parse(JSON.stringify(config.factors))
  for( var key in features){
    features[key]=pt.features[key]
  }

  /* ----- Transformed Features ----- */
  features.race = raceMapping(features.race)
  features.bmi=Math.floor(features.bmi/5)*5+2.5
  // Lung Cancer Screening

  return features
}

function raceMapping(race){
  const raceMap = {
    // Common
    "Non-hispanic white":"Non-hispanic white",
    "Hispanic":"Hispanic",
    // CRC Screening
    "Non-hispanic black":"Non-hispanic Black/African American",
    "All Other Race":"Non-Hispanic Unknown Race",
    // Lung Cancer Screening
    "Non-hispanic Black/African American":"Non-hispanic Black/African American",
    "Non-Hispanic American Indian/Alaska Native":"Non-Hispanic American Indian/Alaska Native",
    "Non-Hispanic Asian or Pacific Islander":"Non-Hispanic Asian or Pacific Islander",
    "Non-Hispanic Unknown Race":"Non-Hispanic Unknown Race"
  }
  return raceMap[race] || "Non-Hispanic Unknown Race"

}
module.exports= qalygain
